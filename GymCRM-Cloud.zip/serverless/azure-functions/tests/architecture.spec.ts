/**
 * Testes de arquitetura (ArchUnitTS) — Vertical Slice + Clean Architecture.
 *
 * Estrutura esperada:  src/features/<slice>/{domain,application,infrastructure,presentation}
 *                      src/shared/Result.ts      (kernel funcional)
 *                      src/composition.ts        (composition root)
 *                      src/functions/*.ts        (entrypoints Azure Functions — "main" do serverless)
 *
 * Regra de dependência (Clean Architecture):
 *   presentation ──► application ──► domain          infrastructure ──► application ──► domain
 *
 * Vertical Slice: um slice nunca importa outro slice (comunicação só via contratos/shared).
 */
import fs from "fs";
import path from "path";
import { projectFiles } from "archunit";

/* ───────────────────────── Configuração deste projeto ───────────────────────── */
const PROJETO = "azure-functions (enviar-email)";
/** Único arquivo de src/shared que domain/application podem usar. */
const SHARED_PERMITIDO = "Result.ts";
/** Módulos nativos do Node tolerados em domain/application (todo o resto é pacote externo = proibido). */
const NODE_BUILTINS_PERMITIDOS = ["crypto", "fs", "path"];
/** Nomes de arquivo aceitos na camada de apresentação (adaptador HTTP da função). */
const NOME_PRESENTATION = /Http\.ts$/;
/** Quem compõe o sistema: composition root e entrypoints das funções. */
const COMPOSITION_ROOTS = ["composition.ts"];
const ENTRYPOINTS = "src/functions/**";
/* ─────────────────────────────────────────────────────────────────────────────── */

jest.setTimeout(120_000);

const SRC = path.resolve(__dirname, "../src");
const FEATURES_DIR = path.join(SRC, "features");
const LAYERS = ["domain", "application", "infrastructure", "presentation"];

const F = "src/features/**";
const domain = `${F}/domain/**`;
const application = `${F}/application/**`;
const infrastructure = `${F}/infrastructure/**`;
const presentation = `${F}/presentation/**`;

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const norm = (p: string) => p.replace(/\\/g, "/");

/** Descobre os slices: diretórios de features que contêm pastas de camada. */
function descobrirSlices(dir = FEATURES_DIR, rel = ""): string[] {
  const entradas = fs.readdirSync(dir, { withFileTypes: true }).filter((e) => e.isDirectory());
  if (rel && entradas.some((e) => LAYERS.includes(e.name))) return [rel];
  return entradas.flatMap((e) => descobrirSlices(path.join(dir, e.name), rel ? `${rel}/${e.name}` : e.name));
}
const SLICES = descobrirSlices();

/** Imports de pacotes (não relativos) de um arquivo-fonte. */
function pacotesImportados(conteudo: string): string[] {
  const re = /(?:import|export)\s[^'"]*?from\s+["']([^"']+)["']|import\s+["']([^"']+)["']|require\(\s*["']([^"']+)["']\s*\)/g;
  return [...conteudo.matchAll(re)]
    .map((m) => m[1] ?? m[2] ?? m[3])
    .filter((spec) => !spec.startsWith("."))
    .map((spec) => spec.replace(/^node:/, ""));
}

describe(`[${PROJETO}] Arquitetura: Vertical Slice + Clean Architecture`, () => {
  describe("Estrutura (Vertical Slice)", () => {
    it("existem slices em src/features", () => {
      expect(SLICES.length).toBeGreaterThan(0);
    });

    it("todo arquivo de feature está em <contexto>/<slice>/<camada>/ (anatomia do slice)", async () => {
      const anatomia = /(?:^|\/)src\/features\/(?:[^/]+\/)+(domain|application|infrastructure|presentation)\/[^/]+\.ts$/;
      const rule = projectFiles()
        .inFolder(`${F}`)
        .should()
        .adhereTo((f) => anatomia.test(norm(f.path)), "arquivo de feature fora de <slice>/<camada>/");
      await expect(rule).toPassAsync();
    });

    it("todo slice possui as camadas domain e application", () => {
      const faltando = SLICES.flatMap((s) =>
        ["domain", "application"].filter((l) => !fs.existsSync(path.join(FEATURES_DIR, s, l))).map((l) => `${s}/${l}`)
      );
      expect(faltando).toEqual([]);
    });

    it.each(SLICES)("slice '%s' não depende de nenhum outro slice", async (slice) => {
      const rule = projectFiles()
        .inFolder(`src/features/${slice}/**`)
        .shouldNot()
        .dependOnFiles()
        .inFolder(new RegExp(`src/features/(?!${esc(slice)}/)`));
      // Com um único slice não há "outros slices": alvo vazio é legítimo (o sujeito existe, garantido pelo teste de slices).
      expect(await rule.check({ allowEmptyTests: true })).toEqual([]);
    });

    it("presentation segue a convenção de nomes (*Controller.ts / *.routes.ts)", async () => {
      const rule = projectFiles().inFolder(presentation).should().haveName(NOME_PRESENTATION);
      await expect(rule).toPassAsync();
    });
  });

  describe("Regra de dependência (Clean Architecture)", () => {
    it("domain não depende de application, infrastructure nem presentation", async () => {
      for (const alvo of [application, infrastructure, presentation]) {
        const rule = projectFiles().inFolder(domain).shouldNot().dependOnFiles().inFolder(alvo);
        await expect(rule).toPassAsync();
      }
    });

    it("domain só usa shared/Result", async () => {
      const rule = projectFiles().inFolder(domain).shouldNot().dependOnFiles().inFolder("src/shared/**").withName(new RegExp(`^(?!${esc(SHARED_PERMITIDO)}$)`));
      expect(await rule.check({ allowEmptyTests: true })).toEqual([]);
    });

    it("application não depende de infrastructure nem presentation", async () => {
      for (const alvo of [infrastructure, presentation]) {
        const rule = projectFiles().inFolder(application).shouldNot().dependOnFiles().inFolder(alvo);
        await expect(rule).toPassAsync();
      }
    });

    it("application só usa shared/Result", async () => {
      const rule = projectFiles().inFolder(application).shouldNot().dependOnFiles().inFolder("src/shared/**").withName(new RegExp(`^(?!${esc(SHARED_PERMITIDO)}$)`));
      expect(await rule.check({ allowEmptyTests: true })).toEqual([]);
    });

    it("infrastructure não depende de presentation", async () => {
      const rule = projectFiles().inFolder(infrastructure).shouldNot().dependOnFiles().inFolder(presentation);
      await expect(rule).toPassAsync();
    });

    it("presentation não depende de infrastructure (fala só com application)", async () => {
      const rule = projectFiles().inFolder(presentation).shouldNot().dependOnFiles().inFolder(infrastructure);
      await expect(rule).toPassAsync();
    });

    it("domain e application não importam pacotes externos (express, zod, jsonwebtoken, pg...)", async () => {
      for (const camada of [domain, application]) {
        const rule = projectFiles()
          .inFolder(camada)
          .should()
          .adhereTo(
            (f) => pacotesImportados(f.content).every((p) => NODE_BUILTINS_PERMITIDOS.includes(p)),
            "domain/application não podem depender de frameworks ou drivers"
          );
        await expect(rule).toPassAsync();
      }
    });

    it("shared não depende de features", async () => {
      const rule = projectFiles().inFolder("src/shared/**").shouldNot().dependOnFiles().inFolder(F);
      await expect(rule).toPassAsync();
    });

    it("features não dependem do composition root nem dos entrypoints das funções", async () => {
      for (const root of COMPOSITION_ROOTS) {
        const rule = projectFiles().inFolder(F).shouldNot().dependOnFiles().withName(root);
        await expect(rule).toPassAsync();
      }
      const rule = projectFiles().inFolder(F).shouldNot().dependOnFiles().inFolder(ENTRYPOINTS);
      await expect(rule).toPassAsync();
    });
  });

  describe("Higiene", () => {
    it("não há dependências cíclicas em src", async () => {
      const rule = projectFiles().inFolder("src/**").should().haveNoCycles();
      await expect(rule).toPassAsync();
    });
  });
});
