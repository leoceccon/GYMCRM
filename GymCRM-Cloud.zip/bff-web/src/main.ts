import express, { Express, Router } from "express";
import { LoginUseCase } from "./features/autenticacao/login/application/LoginUseCase";
import { InMemoryUsuarioRepository } from "./features/autenticacao/login/infrastructure/InMemoryUsuarioRepository";
import { JwtTokenIssuer } from "./features/autenticacao/login/infrastructure/JwtTokenIssuer";
import { LoginController } from "./features/autenticacao/login/presentation/LoginController";
import { loginRoutes } from "./features/autenticacao/login/presentation/login.routes";
import { ListarCobrancasUseCase } from "./features/financeiro/listar-cobrancas/application/ListarCobrancasUseCase";
import { ListarCobrancasController } from "./features/financeiro/listar-cobrancas/presentation/ListarCobrancasController";
import { listarCobrancasRoutes } from "./features/financeiro/listar-cobrancas/presentation/listarCobrancas.routes";
import { MonitorarEventosUseCase } from "./features/eventos/monitorar-eventos/application/MonitorarEventosUseCase";
import { MonitorarEventosController } from "./features/eventos/monitorar-eventos/presentation/MonitorarEventosController";
import { monitorarEventosRoutes } from "./features/eventos/monitorar-eventos/presentation/monitorarEventos.routes";
import { CriarMatriculaUseCase } from "./features/matriculas/criar-matricula/application/CriarMatriculaUseCase";
import { CriarMatriculaController } from "./features/matriculas/criar-matricula/presentation/CriarMatriculaController";
import { criarMatriculaRoutes } from "./features/matriculas/criar-matricula/presentation/criarMatricula.routes";
import { ListarMatriculasUseCase } from "./features/matriculas/listar-matriculas/application/ListarMatriculasUseCase";
import { ListarMatriculasController } from "./features/matriculas/listar-matriculas/presentation/ListarMatriculasController";
import { listarMatriculasRoutes } from "./features/matriculas/listar-matriculas/presentation/listarMatriculas.routes";
import { ConsultarOpcoesMatriculaUseCase } from "./features/matriculas/opcoes-matricula/application/ConsultarOpcoesMatriculaUseCase";
import { ConsultarOpcoesMatriculaController } from "./features/matriculas/opcoes-matricula/presentation/ConsultarOpcoesMatriculaController";
import { consultarOpcoesMatriculaRoutes } from "./features/matriculas/opcoes-matricula/presentation/consultarOpcoesMatricula.routes";
import { ListarNotificacoesUseCase } from "./features/notificacoes/listar-notificacoes/application/ListarNotificacoesUseCase";
import { ListarNotificacoesController } from "./features/notificacoes/listar-notificacoes/presentation/ListarNotificacoesController";
import { listarNotificacoesRoutes } from "./features/notificacoes/listar-notificacoes/presentation/listarNotificacoes.routes";
import { ConsultarSessaoUseCase } from "./features/sessao/consultar-sessao/application/ConsultarSessaoUseCase";
import { ConsultarSessaoController } from "./features/sessao/consultar-sessao/presentation/ConsultarSessaoController";
import { consultarSessaoRoutes } from "./features/sessao/consultar-sessao/presentation/consultarSessao.routes";
import { Downstream } from "./shared/downstream/contracts";
import { errorHandler } from "./shared/http/ErrorMiddleware";
import { httpDownstream } from "./shared/http/HttpDownstream";
import { sessionMiddleware } from "./shared/http/SessionMiddleware";

export interface AppOptions { jwtSecret: string; downstream: Downstream }

/** Composition root: único lugar que conhece todos os slices e liga portas a adaptadores. */
export function buildApp(o: AppOptions): Express {
  const d = o.downstream;

  const login = new LoginController(new LoginUseCase(new InMemoryUsuarioRepository(), new JwtTokenIssuer(o.jwtSecret)));
  const sessao = new ConsultarSessaoController(new ConsultarSessaoUseCase());
  const opcoes = new ConsultarOpcoesMatriculaController(new ConsultarOpcoesMatriculaUseCase(d.cadastros));
  const listarMatriculas = new ListarMatriculasController(new ListarMatriculasUseCase(d.matriculas, d.cadastros, d.financeiro));
  const criarMatricula = new CriarMatriculaController(new CriarMatriculaUseCase(d.matriculas));
  const cobrancas = new ListarCobrancasController(new ListarCobrancasUseCase(d.financeiro, d.matriculas, d.cadastros));
  const notificacoes = new ListarNotificacoesController(new ListarNotificacoesUseCase(d.notificacoes));
  const eventos = new MonitorarEventosController(new MonitorarEventosUseCase(d.matriculas, d.financeiro, d.notificacoes));

  const api = Router();
  api.use(consultarSessaoRoutes(sessao));
  api.use(consultarOpcoesMatriculaRoutes(opcoes));
  api.use(listarMatriculasRoutes(listarMatriculas));
  api.use(criarMatriculaRoutes(criarMatricula));
  api.use(listarCobrancasRoutes(cobrancas));
  api.use(listarNotificacoesRoutes(notificacoes));
  api.use(monitorarEventosRoutes(eventos));
  api.use(errorHandler);

  const app = express();
  app.use(express.json());
  app.get("/health", (_req, res) => { res.json({ status: "ok", service: "bff-web" }); });
  app.use(loginRoutes(login));
  app.use("/api", sessionMiddleware(o.jwtSecret));
  app.use(api);
  return app;
}

if (require.main === module) {
  const env = process.env;
  const downstream = httpDownstream({
    cadastros: env.CADASTROS_URL ?? "http://localhost:3001",
    matriculas: env.MATRICULAS_URL ?? "http://localhost:3002",
    financeiro: env.FINANCEIRO_URL ?? "http://localhost:3003",
    notificacoes: env.NOTIFICACOES_URL ?? "http://localhost:3004",
  });
  const port = Number(env.PORT ?? 4000);
  buildApp({ jwtSecret: env.JWT_SECRET ?? "dev-secret-troque-em-producao", downstream })
    .listen(port, () => console.log(`bff-web na porta ${port}`));
}
