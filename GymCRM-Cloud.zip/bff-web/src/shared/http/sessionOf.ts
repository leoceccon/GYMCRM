import { Response } from "express";
import { Session } from "../kernel/Session";

export const sessionOf = (res: Response): Session => res.locals.session as Session;
