import { RequestHandler } from "express";
import { Perfil, Session } from "../kernel/Session";

export const exigir = (...perfis: Perfil[]): RequestHandler => (_req, res, next) => {
  const s = res.locals.session as Session;
  if (!perfis.includes(s.perfil)) { res.status(403).json({ error: "ACESSO_NEGADO" }); return; }
  next();
};

export const staff = exigir("ADMIN", "RECEPCIONISTA");
