import { NextFunction, Request, RequestHandler, Response } from "express";
import { UpstreamError } from "./HttpJson";

export const asyncHandler = (fn: (req: Request, res: Response) => Promise<void>): RequestHandler =>
  (req: Request, res: Response, next: NextFunction) => { fn(req, res).catch(next); };

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction): void {
  if (err instanceof UpstreamError) {
    console.error(`[bff] ${err.message}`);
    res.status(502).json({ error: "SERVICO_INDISPONIVEL", servico: err.service });
    return;
  }
  console.error("[bff] erro não tratado:", err);
  res.status(500).json({ error: "ERRO_INTERNO" });
}
