export type Perfil = "ADMIN" | "RECEPCIONISTA" | "INSTRUTOR" | "ALUNO";

export interface Session {
  requestId?: string;
  userId: string;
  tenantId: string;
  perfil: Perfil;
  token: string;
}
