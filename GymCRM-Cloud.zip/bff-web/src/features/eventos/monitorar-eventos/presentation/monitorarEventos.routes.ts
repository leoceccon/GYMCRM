import { Router } from "express";
import { asyncHandler } from "../../../../shared/http/ErrorMiddleware";
import { staff } from "../../../../shared/http/RbacMiddleware";
import { MonitorarEventosController } from "./MonitorarEventosController";

export function monitorarEventosRoutes(controller: MonitorarEventosController): Router {
  const router = Router();
  router.get("/api/eventos", staff, asyncHandler(controller.handle));
  return router;
}
