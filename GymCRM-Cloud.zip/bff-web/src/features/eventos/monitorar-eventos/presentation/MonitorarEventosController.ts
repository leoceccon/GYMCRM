import { Request, Response } from "express";
import { sessionOf } from "../../../../shared/http/sessionOf";
import { MonitorarEventosUseCase } from "../application/MonitorarEventosUseCase";

export class MonitorarEventosController {
  constructor(private readonly useCase: MonitorarEventosUseCase) {}

  handle = async (_req: Request, res: Response): Promise<void> => {
    res.json(await this.useCase.execute(sessionOf(res)));
  };
}
