export interface EventoRegistrado {
  correlationId: string; name: string; servico: string;
  direcao: "PUBLICACAO" | "CONSUMO"; status: string; tentativas: number; erro: string | null; em: string;
}

export interface EtapaView {
  servico: string; evento: string; direcao: "PUBLICACAO" | "CONSUMO"; status: string;
  tentativas: number; erro: string | null; em: string;
}
export interface FluxoView {
  correlationId: string;
  inicio: string;
  status: "CONCLUIDO" | "EM_ANDAMENTO" | "COM_FALHA";
  etapas: EtapaView[];
}
export interface ResumoFluxos { fluxos: number; concluidos: number; emAndamento: number; comFalha: number }
export interface EventosResponse { resumo: ResumoFluxos; fluxos: FluxoView[]; degradado: string[] }

const ABERTOS = new Set(["PENDENTE", "PROCESSANDO"]);
const LIMITE_FLUXOS = 30;

/** Agrupa eventos de vários serviços por correlationId e deduz o estado de cada fluxo. */
export function montarFluxos(eventos: EventoRegistrado[]): FluxoView[] {
  const porFluxo = new Map<string, EventoRegistrado[]>();
  for (const e of eventos) {
    const lista = porFluxo.get(e.correlationId) ?? [];
    lista.push(e);
    porFluxo.set(e.correlationId, lista);
  }
  return [...porFluxo.entries()].map(([correlationId, evs]) => {
    const ordenados = [...evs].sort((a, b) => +new Date(a.em) - +new Date(b.em) || (a.direcao === "PUBLICACAO" ? -1 : 1));
    const etapas = ordenados.map<EtapaView>((e) => ({
      servico: e.servico, evento: e.name, direcao: e.direcao, status: e.status, tentativas: e.tentativas, erro: e.erro, em: e.em,
    }));
    const status: FluxoView["status"] = etapas.some((e) => e.status === "FALHA")
      ? "COM_FALHA"
      : etapas.some((e) => ABERTOS.has(e.status)) ? "EM_ANDAMENTO" : "CONCLUIDO";
    return { correlationId, inicio: etapas[0].em, status, etapas };
  }).sort((a, b) => +new Date(b.inicio) - +new Date(a.inicio)).slice(0, LIMITE_FLUXOS);
}

export function resumir(fluxos: FluxoView[]): ResumoFluxos {
  return {
    fluxos: fluxos.length,
    concluidos: fluxos.filter((f) => f.status === "CONCLUIDO").length,
    emAndamento: fluxos.filter((f) => f.status === "EM_ANDAMENTO").length,
    comFalha: fluxos.filter((f) => f.status === "COM_FALHA").length,
  };
}
