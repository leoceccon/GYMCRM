import { EventoDTO, IFinanceiroClient, IMatriculasClient, INotificacoesClient } from "../../../../shared/downstream/contracts";
import { opcional } from "../../../../shared/kernel/degradacao";
import { Session } from "../../../../shared/kernel/Session";
import { EventosResponse, montarFluxos, resumir } from "../domain/FluxoEventos";

export class MonitorarEventosUseCase {
  constructor(
    private readonly matriculas: IMatriculasClient,
    private readonly financeiro: IFinanceiroClient,
    private readonly notificacoes: INotificacoesClient,
  ) {}

  async execute(s: Session): Promise<EventosResponse> {
    const degradado: string[] = [];
    const listas = await Promise.all([
      opcional("matriculas", this.matriculas.eventos(s), [] as EventoDTO[], degradado),
      opcional("financeiro", this.financeiro.eventos(s), [] as EventoDTO[], degradado),
      opcional("notificacoes", this.notificacoes.eventos(s), [] as EventoDTO[], degradado),
    ]);
    const fluxos = montarFluxos(listas.flat());
    return { resumo: resumir(fluxos), fluxos, degradado: [...new Set(degradado)] };
  }
}
