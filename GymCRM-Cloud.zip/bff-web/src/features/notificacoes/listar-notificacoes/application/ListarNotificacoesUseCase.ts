import { INotificacoesClient } from "../../../../shared/downstream/contracts";
import { Session } from "../../../../shared/kernel/Session";
import { NotificacaoResumo } from "../domain/NotificacaoResumo";

export class ListarNotificacoesUseCase {
  constructor(private readonly notificacoes: INotificacoesClient) {}

  execute(s: Session): Promise<NotificacaoResumo[]> {
    return this.notificacoes.listar(s);
  }
}
