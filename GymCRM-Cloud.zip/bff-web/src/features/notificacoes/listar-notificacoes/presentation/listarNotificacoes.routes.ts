import { Router } from "express";
import { asyncHandler } from "../../../../shared/http/ErrorMiddleware";
import { staff } from "../../../../shared/http/RbacMiddleware";
import { ListarNotificacoesController } from "./ListarNotificacoesController";

export function listarNotificacoesRoutes(controller: ListarNotificacoesController): Router {
  const router = Router();
  router.get("/api/notificacoes", staff, asyncHandler(controller.handle));
  return router;
}
