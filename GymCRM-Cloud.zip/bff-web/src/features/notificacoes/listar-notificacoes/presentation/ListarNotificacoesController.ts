import { Request, Response } from "express";
import { sessionOf } from "../../../../shared/http/sessionOf";
import { ListarNotificacoesUseCase } from "../application/ListarNotificacoesUseCase";

export class ListarNotificacoesController {
  constructor(private readonly useCase: ListarNotificacoesUseCase) {}

  handle = async (_req: Request, res: Response): Promise<void> => {
    res.json(await this.useCase.execute(sessionOf(res)));
  };
}
