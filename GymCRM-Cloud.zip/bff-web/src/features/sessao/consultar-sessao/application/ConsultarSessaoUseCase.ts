import { Session } from "../../../../shared/kernel/Session";
import { SessaoAtual } from "../domain/SessaoAtual";

export class ConsultarSessaoUseCase {
  execute(s: Session): SessaoAtual {
    const { token: _token, ...sessao } = s;
    return sessao;
  }
}
