import { Perfil } from "../../../../shared/kernel/Session";

/** Sessão exposta ao cliente: nunca inclui o token. */
export interface SessaoAtual {
  requestId?: string;
  userId: string;
  tenantId: string;
  perfil: Perfil;
}
