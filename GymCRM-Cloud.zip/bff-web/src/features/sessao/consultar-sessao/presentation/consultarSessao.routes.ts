import { Router } from "express";
import { ConsultarSessaoController } from "./ConsultarSessaoController";

export function consultarSessaoRoutes(controller: ConsultarSessaoController): Router {
  const router = Router();
  router.get("/api/me", controller.handle);
  return router;
}
