import { Request, Response } from "express";
import { sessionOf } from "../../../../shared/http/sessionOf";
import { ConsultarSessaoUseCase } from "../application/ConsultarSessaoUseCase";

export class ConsultarSessaoController {
  constructor(private readonly useCase: ConsultarSessaoUseCase) {}

  handle = (_req: Request, res: Response): void => {
    res.json(this.useCase.execute(sessionOf(res)));
  };
}
