import { IMatriculasClient } from "../../../../shared/downstream/contracts";
import { Session } from "../../../../shared/kernel/Session";
import { CriarMatriculaCommand, CriarMatriculaResultado } from "../domain/CriarMatriculaCommand";

export class CriarMatriculaUseCase {
  constructor(private readonly matriculas: IMatriculasClient) {}

  /** O BFF não decide regras de negócio: delega ao matriculas-service e repassa o resultado (201, 409...). */
  async execute(s: Session, cmd: CriarMatriculaCommand): Promise<CriarMatriculaResultado> {
    const out = await this.matriculas.criar(s, cmd);
    return { status: out.status, body: out.body };
  }
}
