export interface CriarMatriculaCommand {
  alunoId: string;
  turmaId: string;
  planoId: string;
}

/** Resposta do serviço de matrículas, repassada sem reinterpretação (status + corpo). */
export interface CriarMatriculaResultado { status: number; body: unknown }
