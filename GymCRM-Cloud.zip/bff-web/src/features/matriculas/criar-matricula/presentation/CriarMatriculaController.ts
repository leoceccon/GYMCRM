import { Request, Response } from "express";
import { z } from "zod";
import { sessionOf } from "../../../../shared/http/sessionOf";
import { CriarMatriculaUseCase } from "../application/CriarMatriculaUseCase";

const criarMatriculaSchema = z.object({ alunoId: z.string().min(1), turmaId: z.string().min(1), planoId: z.string().min(1) });

export class CriarMatriculaController {
  constructor(private readonly useCase: CriarMatriculaUseCase) {}

  handle = async (req: Request, res: Response): Promise<void> => {
    const parsed = criarMatriculaSchema.safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: "VALIDACAO", detalhes: parsed.error.flatten().fieldErrors }); return; }
    const out = await this.useCase.execute(sessionOf(res), parsed.data);
    res.status(out.status).json(out.body);
  };
}
