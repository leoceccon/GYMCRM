import { Router } from "express";
import { asyncHandler } from "../../../../shared/http/ErrorMiddleware";
import { staff } from "../../../../shared/http/RbacMiddleware";
import { CriarMatriculaController } from "./CriarMatriculaController";

export function criarMatriculaRoutes(controller: CriarMatriculaController): Router {
  const router = Router();
  router.post("/api/matriculas", staff, asyncHandler(controller.handle));
  return router;
}
