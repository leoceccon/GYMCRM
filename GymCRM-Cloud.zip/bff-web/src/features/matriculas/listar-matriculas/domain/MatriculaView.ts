/** Dados de origem (vindos de outros serviços) que esta visão precisa; declarados localmente. */
export interface MatriculaOrigem { id: string; alunoId: string; turmaId: string; planoId: string; status: string; dataInicio: string; dataFim: string }
export interface AlunoOrigem { id: string; nome: string; email: string }
export interface PlanoOrigem { id: string; nome: string; valor: number }
export interface CobrancaOrigem { matriculaId: string; valor: number; vencimento: string; status: string }

export interface MatriculaView {
  id: string;
  status: string;
  dataInicio: string;
  dataFim: string;
  turmaId: string;
  aluno: { id: string; nome: string | null; email: string | null };
  plano: { id: string; nome: string | null; valor: number | null };
  cobranca: { status: string; valor: number; vencimento: string } | null;
}

export interface MatriculasResponse { itens: MatriculaView[]; degradado: string[] }

/** API Composition: junta matrícula + aluno + plano + cobrança; ausência de dado vira null. */
export function comporMatriculas(
  matriculas: MatriculaOrigem[], alunos: AlunoOrigem[], planos: PlanoOrigem[], cobrancas: CobrancaOrigem[],
): MatriculaView[] {
  const alunoPorId = new Map(alunos.map((a) => [a.id, a]));
  const planoPorId = new Map(planos.map((p) => [p.id, p]));
  const cobrancaPorMatricula = new Map(cobrancas.map((c) => [c.matriculaId, c]));

  return matriculas.map<MatriculaView>((m) => {
    const aluno = alunoPorId.get(m.alunoId);
    const plano = planoPorId.get(m.planoId);
    const c = cobrancaPorMatricula.get(m.id);
    return {
      id: m.id,
      status: m.status,
      dataInicio: m.dataInicio,
      dataFim: m.dataFim,
      turmaId: m.turmaId,
      aluno: { id: m.alunoId, nome: aluno?.nome ?? null, email: aluno?.email ?? null },
      plano: { id: m.planoId, nome: plano?.nome ?? null, valor: plano?.valor ?? null },
      cobranca: c ? { status: c.status, valor: c.valor, vencimento: c.vencimento } : null,
    };
  });
}
