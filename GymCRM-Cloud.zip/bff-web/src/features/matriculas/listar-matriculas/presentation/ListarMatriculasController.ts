import { Request, Response } from "express";
import { sessionOf } from "../../../../shared/http/sessionOf";
import { ListarMatriculasUseCase } from "../application/ListarMatriculasUseCase";

export class ListarMatriculasController {
  constructor(private readonly useCase: ListarMatriculasUseCase) {}

  handle = async (_req: Request, res: Response): Promise<void> => {
    res.json(await this.useCase.execute(sessionOf(res)));
  };
}
