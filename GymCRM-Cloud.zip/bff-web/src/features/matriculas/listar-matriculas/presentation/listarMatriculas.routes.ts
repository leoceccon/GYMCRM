import { Router } from "express";
import { asyncHandler } from "../../../../shared/http/ErrorMiddleware";
import { staff } from "../../../../shared/http/RbacMiddleware";
import { ListarMatriculasController } from "./ListarMatriculasController";

export function listarMatriculasRoutes(controller: ListarMatriculasController): Router {
  const router = Router();
  router.get("/api/matriculas", staff, asyncHandler(controller.handle));
  return router;
}
