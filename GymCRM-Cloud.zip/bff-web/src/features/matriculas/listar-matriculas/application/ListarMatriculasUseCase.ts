import { ICadastrosClient, IFinanceiroClient, IMatriculasClient } from "../../../../shared/downstream/contracts";
import { opcional } from "../../../../shared/kernel/degradacao";
import { Session } from "../../../../shared/kernel/Session";
import { comporMatriculas, MatriculasResponse } from "../domain/MatriculaView";

export class ListarMatriculasUseCase {
  constructor(
    private readonly matriculas: IMatriculasClient,
    private readonly cadastros: ICadastrosClient,
    private readonly financeiro: IFinanceiroClient,
  ) {}

  async execute(s: Session): Promise<MatriculasResponse> {
    const degradado: string[] = [];
    const [matriculas, alunos, planos, cobrancas] = await Promise.all([
      this.matriculas.listar(s), // fonte principal: se falhar, o erro sobe (502)
      opcional("cadastros", this.cadastros.alunos(s), [], degradado),
      opcional("cadastros", this.cadastros.planos(s), [], degradado),
      opcional("financeiro", this.financeiro.cobrancas(s), [], degradado),
    ]);
    return { itens: comporMatriculas(matriculas, alunos, planos, cobrancas), degradado: [...new Set(degradado)] };
  }
}
