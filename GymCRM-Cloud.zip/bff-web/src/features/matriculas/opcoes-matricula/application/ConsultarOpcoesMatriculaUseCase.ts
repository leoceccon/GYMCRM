import { ICadastrosClient } from "../../../../shared/downstream/contracts";
import { Session } from "../../../../shared/kernel/Session";
import { OpcoesMatricula } from "../domain/OpcoesMatricula";

export class ConsultarOpcoesMatriculaUseCase {
  constructor(private readonly cadastros: ICadastrosClient) {}

  async execute(s: Session): Promise<OpcoesMatricula> {
    const [alunos, planos] = await Promise.all([this.cadastros.alunos(s), this.cadastros.planos(s)]);
    return { alunos, planos };
  }
}
