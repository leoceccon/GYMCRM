export interface AlunoOpcao { id: string; nome: string; email: string }
export interface PlanoOpcao { id: string; nome: string; valor: number; duracaoMeses: number }

/** Dados para preencher o formulário de nova matrícula. */
export interface OpcoesMatricula { alunos: AlunoOpcao[]; planos: PlanoOpcao[] }
