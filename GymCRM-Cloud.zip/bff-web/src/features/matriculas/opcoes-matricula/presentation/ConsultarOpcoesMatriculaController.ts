import { Request, Response } from "express";
import { sessionOf } from "../../../../shared/http/sessionOf";
import { ConsultarOpcoesMatriculaUseCase } from "../application/ConsultarOpcoesMatriculaUseCase";

export class ConsultarOpcoesMatriculaController {
  constructor(private readonly useCase: ConsultarOpcoesMatriculaUseCase) {}

  handle = async (_req: Request, res: Response): Promise<void> => {
    res.json(await this.useCase.execute(sessionOf(res)));
  };
}
