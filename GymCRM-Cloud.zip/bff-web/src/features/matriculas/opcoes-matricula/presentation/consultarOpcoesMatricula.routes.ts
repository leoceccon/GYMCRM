import { Router } from "express";
import { asyncHandler } from "../../../../shared/http/ErrorMiddleware";
import { staff } from "../../../../shared/http/RbacMiddleware";
import { ConsultarOpcoesMatriculaController } from "./ConsultarOpcoesMatriculaController";

export function consultarOpcoesMatriculaRoutes(controller: ConsultarOpcoesMatriculaController): Router {
  const router = Router();
  router.get("/api/matriculas/opcoes", staff, asyncHandler(controller.handle));
  return router;
}
