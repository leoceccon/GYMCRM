import { ICadastrosClient, IFinanceiroClient, IMatriculasClient } from "../../../../shared/downstream/contracts";
import { opcional } from "../../../../shared/kernel/degradacao";
import { Session } from "../../../../shared/kernel/Session";
import { CobrancasResponse, comporCobrancas, totalizar } from "../domain/CobrancaView";

export class ListarCobrancasUseCase {
  constructor(
    private readonly financeiro: IFinanceiroClient,
    private readonly matriculas: IMatriculasClient,
    private readonly cadastros: ICadastrosClient,
  ) {}

  async execute(s: Session): Promise<CobrancasResponse> {
    const degradado: string[] = [];
    const cobrancas = await this.financeiro.cobrancas(s); // fonte principal
    const [matriculas, alunos, planos] = await Promise.all([
      opcional("matriculas", this.matriculas.listar(s), [], degradado),
      opcional("cadastros", this.cadastros.alunos(s), [], degradado),
      opcional("cadastros", this.cadastros.planos(s), [], degradado),
    ]);
    const itens = comporCobrancas(cobrancas, matriculas, alunos, planos);
    return { itens, totais: totalizar(itens), degradado: [...new Set(degradado)] };
  }
}
