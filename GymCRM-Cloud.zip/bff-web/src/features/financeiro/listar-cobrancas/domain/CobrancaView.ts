export interface CobrancaOrigem { id: string; matriculaId: string; valor: number; vencimento: string; status: string }
export interface MatriculaRef { id: string; alunoId: string; planoId: string }
export interface AlunoRef { id: string; nome: string }
export interface PlanoRef { id: string; nome: string }

export interface CobrancaView {
  id: string;
  matriculaId: string;
  valor: number;
  vencimento: string;
  status: string;
  alunoNome: string | null;
  planoNome: string | null;
}
export interface TotaisCobranca { pendente: number; paga: number; recusada: number }
export interface CobrancasResponse { itens: CobrancaView[]; totais: TotaisCobranca; degradado: string[] }

export function comporCobrancas(
  cobrancas: CobrancaOrigem[], matriculas: MatriculaRef[], alunos: AlunoRef[], planos: PlanoRef[],
): CobrancaView[] {
  const matriculaPorId = new Map(matriculas.map((m) => [m.id, m]));
  const alunoPorId = new Map(alunos.map((a) => [a.id, a]));
  const planoPorId = new Map(planos.map((p) => [p.id, p]));
  return cobrancas.map<CobrancaView>((c) => {
    const m = matriculaPorId.get(c.matriculaId);
    return {
      id: c.id, matriculaId: c.matriculaId, valor: c.valor, vencimento: c.vencimento, status: c.status,
      alunoNome: (m && alunoPorId.get(m.alunoId)?.nome) ?? null,
      planoNome: (m && planoPorId.get(m.planoId)?.nome) ?? null,
    };
  });
}

export function totalizar(itens: CobrancaView[]): TotaisCobranca {
  const soma = (st: string) => itens.filter((i) => i.status === st).reduce((t, i) => t + i.valor, 0);
  return { pendente: soma("PENDENTE"), paga: soma("PAGA"), recusada: soma("RECUSADA") };
}
