import { Request, Response } from "express";
import { sessionOf } from "../../../../shared/http/sessionOf";
import { ListarCobrancasUseCase } from "../application/ListarCobrancasUseCase";

export class ListarCobrancasController {
  constructor(private readonly useCase: ListarCobrancasUseCase) {}

  handle = async (_req: Request, res: Response): Promise<void> => {
    res.json(await this.useCase.execute(sessionOf(res)));
  };
}
