import { Router } from "express";
import { asyncHandler } from "../../../../shared/http/ErrorMiddleware";
import { staff } from "../../../../shared/http/RbacMiddleware";
import { ListarCobrancasController } from "./ListarCobrancasController";

export function listarCobrancasRoutes(controller: ListarCobrancasController): Router {
  const router = Router();
  router.get("/api/cobrancas", staff, asyncHandler(controller.handle));
  return router;
}
