import { Request, Response } from "express";
import { z } from "zod";
import { LoginUseCase } from "../application/LoginUseCase";

const loginSchema = z.object({ email: z.string().email(), senha: z.string().min(1) });

export class LoginController {
  constructor(private readonly useCase: LoginUseCase) {}

  handle = async (req: Request, res: Response): Promise<void> => {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: "VALIDACAO" }); return; }
    const r = await this.useCase.execute(parsed.data.email, parsed.data.senha);
    if (!r) { res.status(401).json({ error: "CREDENCIAIS_INVALIDAS" }); return; }
    res.json(r);
  };
}
