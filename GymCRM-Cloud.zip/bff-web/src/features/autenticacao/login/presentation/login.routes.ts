import { Router } from "express";
import { asyncHandler } from "../../../../shared/http/ErrorMiddleware";
import { LoginController } from "./LoginController";

export function loginRoutes(controller: LoginController): Router {
  const router = Router();
  router.post("/auth/login", asyncHandler(controller.handle));
  return router;
}
