import jwt from "jsonwebtoken";
import { ITokenIssuer } from "../application/ports";
import { Usuario } from "../domain/Usuario";

export class JwtTokenIssuer implements ITokenIssuer {
  constructor(private readonly secret: string) {}

  emitir(u: Usuario): string {
    return jwt.sign({ sub: u.id, tenantId: u.tenantId, perfil: u.perfil }, this.secret, { expiresIn: "8h" });
  }
}
