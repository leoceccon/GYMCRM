import { timingSafeEqual } from "crypto";
import { IUsuarioRepository } from "../application/ports";
import { Usuario } from "../domain/Usuario";

interface DemoUser extends Usuario { senha: string }

export const DEMO_USERS: DemoUser[] = [
  { id: "u-admin-a", email: "admin@academia-a.com", senha: "admin123", tenantId: "academia-a", perfil: "ADMIN", nome: "Admin Academia A" },
  { id: "u-recep-a", email: "recepcao@academia-a.com", senha: "recepcao123", tenantId: "academia-a", perfil: "RECEPCIONISTA", nome: "Recepção Academia A" },
  { id: "u-admin-b", email: "admin@academia-b.com", senha: "admin123", tenantId: "academia-b", perfil: "ADMIN", nome: "Admin Academia B" },
];

export class InMemoryUsuarioRepository implements IUsuarioRepository {
  constructor(private readonly users: DemoUser[] = DEMO_USERS) {}

  async autenticar(email: string, senha: string): Promise<Usuario | null> {
    const u = this.users.find((x) => x.email === email);
    if (!u) return null;
    const a = Buffer.from(u.senha), b = Buffer.from(senha);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const { senha: _senha, ...usuario } = u;
    return usuario;
  }
}
