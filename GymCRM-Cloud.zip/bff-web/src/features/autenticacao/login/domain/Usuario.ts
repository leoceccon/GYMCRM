import { Perfil } from "../../../../shared/kernel/Session";

export interface Usuario {
  id: string;
  email: string;
  nome: string;
  tenantId: string;
  perfil: Perfil;
}
