import { Usuario } from "../domain/Usuario";
import { ITokenIssuer, IUsuarioRepository } from "./ports";

export interface LoginResultado {
  token: string;
  usuario: Pick<Usuario, "id" | "nome" | "perfil" | "tenantId">;
}

export class LoginUseCase {
  constructor(private readonly usuarios: IUsuarioRepository, private readonly tokens: ITokenIssuer) {}

  async execute(email: string, senha: string): Promise<LoginResultado | null> {
    const user = await this.usuarios.autenticar(email, senha);
    if (!user) return null;
    return {
      token: this.tokens.emitir(user),
      usuario: { id: user.id, nome: user.nome, perfil: user.perfil, tenantId: user.tenantId },
    };
  }
}
