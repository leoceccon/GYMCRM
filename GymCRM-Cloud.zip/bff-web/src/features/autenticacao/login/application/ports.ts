import { Usuario } from "../domain/Usuario";

export interface IUsuarioRepository {
  /** Devolve o usuário se as credenciais forem válidas; caso contrário, null. */
  autenticar(email: string, senha: string): Promise<Usuario | null>;
}

export interface ITokenIssuer {
  emitir(usuario: Usuario): string;
}
