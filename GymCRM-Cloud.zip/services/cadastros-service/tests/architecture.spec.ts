/**
 * Testes de arquitetura (ArchUnitTS) — Vertical Slice + Clean Architecture.
 *
 * Estrutura esperada:  src/features/<contexto>/<slice>/{domain,application,infrastructure,presentation}
 *                      src/shared/*   (kernel, events, http, messaging, persistence)
 *                      src/db/*       (schema/migração — só infraestrutura)
 *                      src/main.ts    (composition root)
 *
 * Regra de dependência (Clean Architecture):
 *   presentation ──► application ──► domain          infrastructure ──► application ──► domain
 *
 * Vertical Slice: um slice nunca importa outro slice (comunicação só via contratos/shared).
 */
import fs from "fs";
import path from "path";
import { projectFiles } from "archunit";

/* ───────────────────────── Configuração deste projeto ───────────────────────── */
const PROJETO = "cadastros-service";
/** Subpastas de src/shared que a camada de DOMÍNIO pode usar. */
const SHARED_PERMITIDO_DOMAIN = ["kernel", "events"];
/** Subpastas de src/shared que a camada de APLICAÇÃO pode usar (contratos de eventos e kernel, nunca adaptadores). */
const SHARED_PERMITIDO_APPLICATION = ["kernel", "events"];
/** Subpastas de src/shared que a PRESENTATION não pode tocar (acesso a dados/mensageria é da infraestrutura). */
const SHARED_PROIBIDO_PRESENTATION = ["persistence", "messaging"];
/** Módulos nativos do Node tolerados em domain/application (todo o resto é pacote externo = proibido). */
const NODE_BUILTINS_PERMITIDOS = ["crypto", "fs", "path"];
/** Nomes de arquivo aceitos na camada de apresentação. */
const NOME_PRESENTATION = /(Controller\.ts|\.routes\.ts)$/;
/** Arquivos que compõem o sistema (composition root): só eles conhecem todos os slices. */
const COMPOSITION_ROOTS = ["main.ts"];
/* ─────────────────────────────────────────────────────────────────────────────── */

jest.setTimeout(120_000);

const SRC = path.resolve(__dirname, "../src");
const FEATURES_DIR = path.join(SRC, "features");
const LAYERS = ["domain", "application", "infrastructure", "presentation"];

const F = "src/features/**";
const domain = `${F}/domain/**`;
const application = `${F}/application/**`;
const infrastructure = `${F}/infrastructure/**`;
const presentation = `${F}/presentation/**`;

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const norm = (p: string) => p.replace(/\\/g, "/");

/** Todo caminho dentro de src/shared/ EXCETO as subpastas permitidas (o filtro compara com o DIRETÓRIO, sem barra final). */
const sharedExceto = (permitidos: string[]) => new RegExp(`src/shared/(?!(?:${permitidos.map(esc).join("|")})(?:/|$))`);
const sharedSomente = (proibidos: string[]) => new RegExp(`src/shared/(?:${proibidos.map(esc).join("|")})(?:/|$)`);

/** Descobre os slices: diretórios de features que contêm pastas de camada. */
function descobrirSlices(dir = FEATURES_DIR, rel = ""): string[] {
  const entradas = fs.readdirSync(dir, { withFileTypes: true }).filter((e) => e.isDirectory());
  if (rel && entradas.some((e) => LAYERS.includes(e.name))) return [rel];
  return entradas.flatMap((e) => descobrirSlices(path.join(dir, e.name), rel ? `${rel}/${e.name}` : e.name));
}
const SLICES = descobrirSlices();

/** Imports de pacotes (não relativos) de um arquivo-fonte. */
function pacotesImportados(conteudo: string): string[] {
  const re = /(?:import|export)\s[^'"]*?from\s+["']([^"']+)["']|import\s+["']([^"']+)["']|require\(\s*["']([^"']+)["']\s*\)/g;
  return [...conteudo.matchAll(re)]
    .map((m) => m[1] ?? m[2] ?? m[3])
    .filter((spec) => !spec.startsWith("."))
    .map((spec) => spec.replace(/^node:/, ""));
}

describe(`[${PROJETO}] Arquitetura: Vertical Slice + Clean Architecture`, () => {
  describe("Estrutura (Vertical Slice)", () => {
    it("existem slices em src/features", () => {
      expect(SLICES.length).toBeGreaterThan(0);
    });

    it("todo arquivo de feature está em <contexto>/<slice>/<camada>/ (anatomia do slice)", async () => {
      const anatomia = /(?:^|\/)src\/features\/(?:[^/]+\/)+(domain|application|infrastructure|presentation)\/[^/]+\.ts$/;
      const rule = projectFiles()
        .inFolder(`${F}`)
        .should()
        .adhereTo((f) => anatomia.test(norm(f.path)), "arquivo de feature fora de <slice>/<camada>/");
      await expect(rule).toPassAsync();
    });

    it("todo slice possui as camadas domain e application", () => {
      const faltando = SLICES.flatMap((s) =>
        ["domain", "application"].filter((l) => !fs.existsSync(path.join(FEATURES_DIR, s, l))).map((l) => `${s}/${l}`)
      );
      expect(faltando).toEqual([]);
    });

    it.each(SLICES)("slice '%s' não depende de nenhum outro slice", async (slice) => {
      const rule = projectFiles()
        .inFolder(`src/features/${slice}/**`)
        .shouldNot()
        .dependOnFiles()
        .inFolder(new RegExp(`src/features/(?!${esc(slice)}/)`));
      await expect(rule).toPassAsync();
    });

    it("presentation segue a convenção de nomes (*Controller.ts / *.routes.ts)", async () => {
      const rule = projectFiles().inFolder(presentation).should().haveName(NOME_PRESENTATION);
      await expect(rule).toPassAsync();
    });
  });

  describe("Regra de dependência (Clean Architecture)", () => {
    it("domain não depende de application, infrastructure nem presentation", async () => {
      for (const alvo of [application, infrastructure, presentation]) {
        const rule = projectFiles().inFolder(domain).shouldNot().dependOnFiles().inFolder(alvo);
        await expect(rule).toPassAsync();
      }
    });

    it("domain só usa shared/kernel e shared/events (nunca adaptadores)", async () => {
      const rule = projectFiles().inFolder(domain).shouldNot().dependOnFiles().inFolder(sharedExceto(SHARED_PERMITIDO_DOMAIN));
      await expect(rule).toPassAsync();
    });

    it("application não depende de infrastructure nem presentation", async () => {
      for (const alvo of [infrastructure, presentation]) {
        const rule = projectFiles().inFolder(application).shouldNot().dependOnFiles().inFolder(alvo);
        await expect(rule).toPassAsync();
      }
    });

    it("application só usa shared/kernel e shared/events", async () => {
      const rule = projectFiles().inFolder(application).shouldNot().dependOnFiles().inFolder(sharedExceto(SHARED_PERMITIDO_APPLICATION));
      await expect(rule).toPassAsync();
    });

    it("infrastructure não depende de presentation", async () => {
      const rule = projectFiles().inFolder(infrastructure).shouldNot().dependOnFiles().inFolder(presentation);
      await expect(rule).toPassAsync();
    });

    it("presentation não depende de infrastructure (fala só com application)", async () => {
      const rule = projectFiles().inFolder(presentation).shouldNot().dependOnFiles().inFolder(infrastructure);
      await expect(rule).toPassAsync();
    });

    it("presentation não acessa adaptadores de dados/mensageria de shared", async () => {
      const rule = projectFiles().inFolder(presentation).shouldNot().dependOnFiles().inFolder(sharedSomente(SHARED_PROIBIDO_PRESENTATION));
      // Alvo vazio é legítimo aqui (o projeto pode nem ter essas pastas); o sujeito (presentation) é garantido pelo teste de nomes.
      expect(await rule.check({ allowEmptyTests: true })).toEqual([]);
    });

    it("domain e application não importam pacotes externos (express, pg, amqplib, jsonwebtoken...)", async () => {
      for (const camada of [domain, application]) {
        const rule = projectFiles()
          .inFolder(camada)
          .should()
          .adhereTo(
            (f) => pacotesImportados(f.content).every((p) => NODE_BUILTINS_PERMITIDOS.includes(p)),
            "domain/application não podem depender de frameworks ou drivers"
          );
        await expect(rule).toPassAsync();
      }
    });

    it("domain, application e presentation não acessam src/db (schema/migração é da infraestrutura)", async () => {
      for (const camada of [domain, application, presentation]) {
        const rule = projectFiles().inFolder(camada).shouldNot().dependOnFiles().inFolder("src/db/**");
        await expect(rule).toPassAsync();
      }
    });

    it("shared não depende de features", async () => {
      const rule = projectFiles().inFolder("src/shared/**").shouldNot().dependOnFiles().inFolder(F);
      await expect(rule).toPassAsync();
    });

    it("features não dependem do composition root", async () => {
      for (const root of COMPOSITION_ROOTS) {
        const rule = projectFiles().inFolder(F).shouldNot().dependOnFiles().withName(root);
        await expect(rule).toPassAsync();
      }
    });
  });

  describe("Higiene", () => {
    it("não há dependências cíclicas em src", async () => {
      const rule = projectFiles().inFolder("src/**").should().haveNoCycles();
      await expect(rule).toPassAsync();
    });
  });
});
